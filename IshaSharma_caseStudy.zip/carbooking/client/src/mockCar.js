const mockCar = [
    {
        id: 1,
        image : "https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=600",
        Cartitle: "BMW",
        Cardescription: "You can book car as per your choice."
    },
    {
        id: 2,
        image : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDLLdDiTCv8KmxkWF18uKC-7GxktptsCiAPWSNdA9rjQ&s",
        Cartitle: "KWID",
        Cardescription: "You can book car as per your choice."
    },
    {
        id: 3,
        image : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVEhgUFRUYGBgaGhgYGhoaGR4cHxgcHRwcHBocGBocJC4lHB8rHxkcJzooKy8xNTU1HCU7QDs0Py40NTEBDAwMEA8QGhISHjQhISE0NDQ0NDQ0NDExNDE0NDQ0NDQ0NDQ0NDQ0NDE0NDQ0NDE0NDE0MTQ3MTQ0MTQ0NDQ0Nv/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABQYEBwECAwj/xABEEAACAQIEAwYCBgcGBQUAAAABAgADEQQSITEFBkETIlFhcZGBoQcUMkJSsSNicqKywfAWM4KS0eEVQ0TS8SQ0c5PC/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAECAwT/xAAgEQEBAQADAAICAwAAAAAAAAAAARECEiEDMUFhUaGx/9oADAMBAAIRAxEAPwDc0REBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERARExsZi6dJGqVHVEUXZmIAA8yYGTOCZUcdzgxUnC4d6osSKtRhQpEi+is9mbbcLbXeVPiXGsRUU/WOIrR1/u8Ghc5bbCvUyqrDW5BgbVaso3I1uRrvbew6zGwPFaNYstKojldGCtcr07w3GommMPiOHrUR1qYitWU3D1MTd8wIIYKjb6bXmDxfmqvTxb1lZUZSCWRFu4YWzEHc/ZO4B666yo+g7xPnk/SPjm0+uVR6UKAnI55xx/63Ef/VQjDX0LE0EvOuOG2OrN60aA+FrmZVLnfHdcVVt/8NA++m0vVNbziaaw3POM64hm9aVP+QkhR52xJ+04I8DSYfwa/OOtO0bVvOZrN+bqzWs6jys9j8SoI9byRwnPAXR1zDTvB1JHjoN/jbz8ZOtO0XuJD8H4/QxNxSfvL9pGGV16aqdxfqLg9CZMSNEREBERAREQEREBERAREQEREBERAREQEREBERA83cAEkgAaknp6zXfNPNObDO4GRN6ZKo7Ob9xlRge8TYrcaaG/QznPvFBRw6pfWq2U/sAZn+FrL/iE07xfigq1UUnRXzkeOUXH72X2lkS1N1aauA+JxFSo5AzKjZVBIuVz6u1jpe9jbpIDijUTWVadMIlwG1Zi4Ul3LM5JN7BbfDrMymFdVYtv+tYA3tY+BvofjOX5ecsG7VBYEaZn3IJNyBfYe5mvGdrnEcVZgUa2VhlI2Av4AeG49JCcTQuSerUvmLn/APPzkhxPhZpjOSWBNiVbYnowI0+F5HJiL5H0sGy/Cy2B9mvFJ4ihWVgSEB67/O286tiAPugfEmcU8MVqVFDEFA7KbanLt7gzpiV1Bta4DWHn4CWVce6Ykjz9CJlU8XYjMSo8beXSY3CqyCoofqbWIuNRp87SR48ncU/ha3mAdNvW3vJp1daWKue6QR1INrH8h/Wkk8PWP3WBHiW6+2nuJUFxLpcIzKL3sDaSfC8Yz5g7ZrWIvvroY1OsWJOKlb3O2/8AX+vvM+lxTbW/9f15SnY2qFcHYMLH8jp7Gd8HiG7yN9pT/Xnv+cvZOq8Uq4YhlY06id5HTQq3jba3QixB6gzYvKPNIxF6FayYlBdl2FRfx079PEdL+k0pQxWvXp6zPTGN3HVylRO9TdTqjeV916FTcSX0mx9ETmVHkjm5MbTKPZcTTH6RBoG2BdL65CT8LjylopV0b7LK3oQfymHR7REQEREBERAREQEREBERAREQEREBERATicyP4vjxRplz6AefT+Z+EDV/0rYio+JprSp1KmSmR3EZluX72oFhqij4TWFbDVUqqlSm6OxVLOjKTmbvWDAX1t7zcD8wU75cmb1vrqehHqZ7vUo16YWoisl7hHRXUeBCtsd9rS6jVdfF0WQUO17MqBclWIGXddNS1/yO89zjQFBXHUWCg2UtXVrDZQpQrf4zYZ4PgCuX6vRA02pJf/NbN66zunCOGr/01H40kb8xGpka4xvHTUwuRb5yy7oB3dDq1tdfGRSPYGkbFiVYWN/unS46k3m1MTy9wlhY0lXzRSp+BVxNY1KWDXGvTrioKCs6K1MkONRlZhULbC5IG/QaiOxkc1+HVnYVaQBLrldCQpGwN89rg2Go8J3Xl3E79mu347+wF5YMRhMKSRhcYj01yjNWWozkkXIGXIuUW8L6+3OGo0l0qMja7qj7egP5mWUqvNy1ijuij1D/AMlntV4DinFnamfN89x42OXYy0p9TzC408f0oPwu6j85L4ahgTYJWroT0z6X/VDbj4mbktcuXyZ9NatytVJt2mHJ8A5B9it5McL5Exp7y0gRs32xodrF8oO3S82AmBW3drlx4OgP5ie1BCn/AC0YeKZ0PujAfKavC4nH5v5as4zy3iQ5plaYy2N84NjbYm5HXbynvgOScfVIqpQGWwBLNlD6WuuYXPTXabWHEaYFnSqB+2XHs5/lPM8Uw33K70z8f4Tp8pzvFufJrXi8kcSXVsMAANzVQDTz29zMevy/iktnouul1CsrZvTbTzvb5zYFfidEghsThnB6VKjofe+X90Tx/wCM4Vd2oKb6MpSqpI/Wp5ip/aAkzG+2tb1lxGHqpUCtTdbi+jZlNgVIVr5dbHb4aWtGA5hqoUrJo7a5QRc6Ws63sRe9nsoIsTrrLD/aKmt8j0Tf8Pct7oNPKcU+YmvdQhPQrUpD8zHpMbHwWIz00fQFlUkXBsSASLjTxmVea1TjFdjfsqjfsFXP7j6zt/x2uozGniUt+Om6j/MRb4GZXWyYmvsJzyVIDjMvmMrD47H4iWjBcxYaoBaqoJ6MQp+cGpmJ0DX1Go8p3hSIiAiIgIiICIiAiIgIiICQPM+JCLTLGwL2J8BlYX+cnpr76Vsd2dKiBuzPbYbBfH1gRHNdSnUS3blLG9lCMScrAZGNyhudTe1ukgqXF3GgZSPBl/mLSvviCbNmB111B/KZ2Cph6ZN9Va2/iAZPUTOL4m7Ugq00z5lYP2lRMuU9UU98G1vtC19mGkyn4lT++j36lWU+wNpV69bIBr0/mZjNxAyaLU+Pwx+849Uv/CZ2wmEp4jNTRUcEXd3S4QdLBtWc9OgteU6pjLyx8M4scNSZltme2hF9Rsfhe/xlFkTC0KKhEpoABYFhf3O0huJ1PGnSt4hPyN5VcTxOpVOYqz32ZiAD45MxAI9NJ4Gq6nZkv0Ox9tDLPtLEjUGvdW3kLn2nvwWqXqBSpykgZQ2QsToDmINj8DI2niL+v9ayb4Li8lS1h3rK+n2xe4I6BgwBtsT6me34748PzT33xsA8vJ2WfLXXNa/6YXUC/e2IsQAdr97xlaxNWh2q4dRjS7sFGWuoNybDMHXTa+2gllpc0ZqfZ6q32VFRlps2WxuA1tDqND4a9ZWqtTEjFmulB8vaI4yZatsq5CSKbO3eB22BmNuXf9WceNsvGf098dwCmlN2apinCEBwteg5QnQBlNNbXPS4OsrbYzAUyFelXcsRkJCU9+lVmzAEXGqgaHa4Jl0xnFkpUyr1eyLujuK2dbFWVzkUqDqEYW1JuJq/mrHI+JxC0CzUC2Zb7qbHYWuFDMQBpv6Tl2/b08Z+sSeG45SqVlo4fhdI1GJUJUxNQtmHQliig6bTo3NwS5OCwSspIKFq2ZSDqCubcbWlabiBujdswOh0QKVOxKuutxcm8l+a8UBiaoNYr2mWrl7JSP0yLVaz7nvVGnOuqwcQ5mxOHcJUw/DqZKqygmq2ZWF1ZWR7FSOonU8345adOr9VwPZ1XZEde1ILLuLCrcHTqOokLjcePqmEc1mQsjppTWpfI+guxuAMxsJhUMQDw7E2YkriKDBsoBOYVdcuwuVEirVT5zxbZstDAkorO/cxAyKguxYmpoOnmSBuQJ2rc+46nTpVTSwAWqrMhBra5WysCBU0IOljIvG86CrQdBRCNUp0UqOilnDUzmZmBsrBrAWJB7oJLbTAr1G+qYTKa4tQqN+jpBwScViNWJbunujaBZqvPmJFGlWqYfBFaocoQ1W90YKwYZjlN2G/QzlOOdpVopWw6U2xCB6L0KmZSGJUB6bg/eBuAVOnWVauWGFwxU4gfoGY9mgK/wDusTq5v3TYD2mdVumNwCm4K4agLElQCVJNmXvAkEjQXFxLPEs2Nm0w+GpmpRr1HVGCujsgUG17MvZoRcMuzCxMu+Hqh1DDruPAjce813huMoyOXZBnbO6NmzqwyoudBZiCAB3svSWfk7FZqLqc2ZajHvC3dYkrYbhdwAdQALy3HPhstl+lliImXUiIgIiICIiAiIgIiICaa+nyuQ2DUeGIPv2QBt8D7zcs099OFJe2wTsLqFxBYeS9mdfUsIGtMJRrIafaqyrVByE/eHTT1tvMvDV2BYDrYzP4hhq1OhUo1WVibVlC69nVSxZToBdlfcb2PnM3gmDS4csnfGdbsNnGa3qL2t5RYzUHUqEjWYbmXbGcCQ3OUrfqNPy0kDjOCOtyozDy3Hw2MioVW1mZxTEWCqdrXPppf+QnilA9oFA1vtY39jr8phcXfvN/hUfAf+Igxa2NZmJ8fHX0+HlMvAcTK90jundeh818CJ2wvClyCpXY00bVFAu9QeKg/ZX9Y+PWdKyYbZRUH62ZT8SLflNzRnpUyva9wdj4g7H1/wB5J0a0r+bu2vfKdD4qf9CJI4SpcA+M3x59XPl8c5T1b6fM7imEdEqKOhJHvuPDpMDE1cHV1bChSeqFT7EBLSu1+IkEkKLG9r72Bte3QaG1zPIcYHUKfQn/AHmu+sT4+q28OqYdO4z1mpt3TTeo4QDxZASrjW9jYdZP4bF4QBkfsMoNrFFN/NSFOnnNe0eKoLM66eFlcEjWxXMpsdATf4TuvEEckrYXJNhey36C99Jy5eOsi18W4ZgayZaNcYc62Clghv0KDQX8dfQbyC4lQrMygPUXKiJ+hqXV8gtmKrsbAaa7DUzGWvPf60oF2IA8zOertYyrXWilEriFKFzmpuwzByD3xl3H855YajiFp1k7Oq3aPTbNnysMmfcldb5/l1vM0cTpD74nU8Yoj73yl02sBeGVspUJWW/jiFA+IyC/vMyrwx2p0kZcpp0zTBWuLMDVq1czWXxqkWv0853bjFMC92t42097zzbjCWuMxHiBp73tGr65x3CmqpSpt2QNKkKKsHNiAzuWtl3zVCT6CWnBcRSiz1XdWqsiU8yKdFRAND0BCgAAndid5Tm43TOxPtOqcRV75T8PKNot1HmnIxZKId7FVeoQMgJucgALEn1WWf6PcfVfFMah0dGFgLAMpDD5ZtyZrzguCqV6gSmuZspexIVVVTYs7HYeQB+EtHDcHVw/FcJTOJDguyui3ARlTNk1GxVx1Oomkz1uYTmcCcyNEREBERAREQEREBERATWn0y0VFHC4ggns8QAbaEowzMASLAk0130my5SPpU7uBWqFVuzxFCpZhcE5soBHUHNYjqNIGo+MOv1YEMXuECMRrkVai3NtAzCpRuBcAqwudDIynj1FNFsSRmvbTu3JWxIPiPaTXMVascNmruKjs4DvkymmxsRTU6ZUtTcWFgTTOnU1XBuKdRTWpuyDdR3cw6a+G0qJzBcRK/3VZk/VYlQfhco39aSWTjtdBd6SOv4gMvzXT5SHNHA1j3Kr0H07rjMt+upsf3veF4FiqfeoMtQeNGpa/qjWv7ERkMSWO45h6g/uai1B9m4QhT074YNbyyyvmmpqZ3GZVuxB2dtkVutr7+QInbEYmoGC16WRhsSmUnx0sAR5iwnnxFwFABBzd713At4bfvCSTB2wmCrY2qxDLuuao5yIMxIRTYG17EKijobDSZVPgFJsW2DNRkdc57QqMpCpn/uwcwBA/ET5Hae/E+DlsMgw1alVWihetSUlXWp/zHKkDOBooYbBdNNTKYdTVqUOIajLQrridNVdKZF7b3daiML76+EqqpiOHPSCliro65kdTmVxpexIBBFxdWAI6gT1wBt7yU4Lw0jhmJqVmyoWQUFbrXU3LJ5lbppuCb/ZBEPh3t+X8xJfpE1y0Qa2IqlFZqGCatSDKGUOi00Vip0a2ZjrfWx6T1wPPWK7RTiX7enmXOrU6ROUEFgpK6XGkxuBYoUKhdlFVHp1MNWpBgrtTclsyE727uvQracNwvCMxCV8TTHQVcMH+DNQqH+Ca42flLGwuL8S4I1Lurh3co2VUohXZiO4pyKMpubEnQTX+IyqodlVLgd1dtrXt52vp4z34Py2TXIRhWVVzMUSohVb20WqiMzNt3b2te+wkXzHUZqmXI626FGW3wI0Ecs/BI8Xxehax8FHUnw0mEpzNd7s3yHpY5h8BOtEKxzPcgaKAbX8ST0HpPdXS+ie5Y++sk4roSt1uNf2r9f11ze1oqWC94dfLwv1Lae047IPUp0wAgd1UkAm2YgXsTrYHbT1l0fkGkouald9tEUFrG/RlGgsb9RpoQQSVTmdRe6qNAL2t16MrEn4KPhOudd7Lop+9c/e6kZr/MS8/wBhcMpyl6x1dRmCjVVZrtY6I2UBSLElhpO1PlXAOSq1Ki5dGu5W5zlSUZ1ysAgD92972BNoFBLDwtve9j82BNvQiY1HOGDKpJH6pN/I76SX4nh+wdDYpfObFtQA2VWYD7N9fYzFbiJ6u3u0T0viV4Vxqpg6i16BAYKy98XGR9bMtxqGW3qZbeVhUq47BV3VialavXLEGxDqBmF9lLXA8gbaCU7geNpMzCrnY5QUKAXupv3i3gQpBsdiJsHkGqavEAyh/slqjvUZ3YKLLnZifvMP9hpG/hG3xOZwJzIpERAREQEREBERAREQEq/0i4U1OGYgAXKoKij9ZGDD8paJGcWwtWojIjhQyspBUG4IsRrEHzlx1/0SEVM2exIB3yqrZnH4g71AL9CTK+uJcaBmA10vp7HSXHmfkXHUG7qF0H2Sp1Av1Ep9fBVU0amy+omkbR5V+jdMbw5MQ9VkqPnK2AKlQxVcy2B1sTv1EweJfRbj8OS1Aiqo2NJyreppvYfAM0picw45UVFxNdURQqqHYBVAsAADoLToePYk/br1j61H/wC6MFgr1KtBDRx6VipOzoAFGlihOVg+4uCRrqDIQU0avRQNmQlBcrY2NTXMptrr/peeTcVdxZndv2nLfxTotW5Qi11Jt06hh8xGGrfi+WqODrio/FUpVUa4y0i7q1z9xGJsTfQi1jYzpjKilsT9TYph3Wk7U3UJ2oubBQGzCmrJYKpzAVCBYbYOJ4PSD18biMzUC4KKpsa1SqS4QMdgqas3p1NpL1Thu2w+fCqirhDXekhK5mOd1zOxLM2Ww1NzfytMq8uY+E4ivVpU6LUxg6SgUqpqr2dt2q1GBvmY3JFiQNBKuyZHYGxsxGhFjbS4udRp85OcZ5WqV1XE4LNiKNRhc5gXViQAKi/q3sTra2umph+YHX6xUZds7BdDqgNk/cAlk1AYxbWyN8v9Z6LXXoh/yr+d7yHap6zyZ28DGQWKnUa4K9qp6FWdSPTK3nMrEU8fXQrTXFVFPdY5qjDzXViLn8pVqAW93JA8FFyfK/STuF4wQAlJXCjZU0/nqfMxgUOUOIm18O6joCyJ8mYaT2q8l44j7CJ+1Xp/90k8IeKsB9XwrBfHsaTk+bPVVmJ+IHlJFeDcwsLrSYA+DYVPkLERqqkeVcZTbXs1KkEN9YpLYjUEEuOomVS4FjapP/qqbHdrYpahF9iRTLHeT2H+i/ib7pQp+TVb/wACtIrmvgGP4bTTtaiinUJA7BmChh0bRSSV11v8pB5Dk/FbHELY7i2Jb+Glb5yPbg1G9nxwNjay0K7WP+NVHzkbS4g7NZ6zqPEkv+Z1mdgKPaB81cKwUlCSiqTY2DFrFdbdNjAlcNy7hSgc13sToX7GgGItewqPmI87WntiODYIAnOznwWqCT8VTL+9K9WakKSWeoa5Z+01GRUFwoVr94nQ321tMRa6/jb3aUWG1Cib0qPfNgC7M9hse4LAk3G9/Sbe+jTgVejTfEYnMKjgKlMgL2dMG/2FAVSzakAbBZq3kHgbY3GIFX9HSdKtVzsFVsyqb7litreFz0n0aoijtERIEREBERAREQEREBERAREQOjKDoQDInHcuYeqO9TW/pJmIGveL/R7TYHsxaa843yNUQmyaeU+hZ41sMrizKDL2THyjiuFOhNwZj4a6sVP3tv2htPpLi3JlCsDYWM13zF9GzrdkBIl0Vzh9ZMVRp4avcqmdafeydi1TLdtSFNmUaNpYkaaSV5pU0eNd6kzYcJToHKhN6Jp5Sy2BvlGumugHWVPE4Wth276lT420P7QmVR5vrImRSQALd13VdNha5t8LSYJbA0sRws4pGqZQc1MICDmGy1h+EkbdTc3FhKhi612JO1za3W5v/XpO+N4k1T7TefgNd7eJJ8ZHVKl5R7GqBOhxI8Jjlp1tIr2qVyfKeVzOLRaBk0cbUQ3Soy+jEfzk3gueOIUrZMVUt4NZh+8JXMp8JyEPgYGx8B9MGOTSotKoPNSp+X+kmsT9KeFxdBsPjcKxRxZsrA2PRl6gg2IM1AKTeBndcKx6H2gZvF8LQVycPW7Smdswyuvk6nQnzW49JG5j4zJHD38J6Lw1/CMGLRpszBVUsx2ABJJ8gN5e+VfoyxuIYPVQ4en1aoLOfHJTOt/NrD1lawvDqqsGTMrDYgkEehGoMvHLfMvE6Fl7U1FFtKoLg+Wa4Yet4xNbh5e4FQwdEUaCWF7sx1Z26s56n8ttJMSt8G5lFUAVaZpN/mU/4unxEsYMiuYiICIiAiIgIiICIiAiIgIiICIiAiIgJwROYgQ/FOXcPXBDoNetprzjn0TU2u1K48hNtxA+ccZ9GuIQ6Zj8JHVORcSv3T7T6cKg7idWoKd1HtKPmD+x9cfcM9qfJ1X8De0+lGwFM/dE4+oU/wAIgfPFLkt+qn2mZT5If8Jm/PqKfhE5GDT8IgaKTkdvwmZCcjn8Jm7vqqeAnP1ZfCNGmqXJB/DM2jySfw/KbaFBfCcikPCNTGsqfJX6syqPIy9VmxMonaNXFKoclINxJLD8r016SyRII+hwtFG0zVWwsJ3iAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgf/2Q==",
        Cartitle: "SCORPIO",
        Cardescription: "You can book car as per your choice."
    },
    {
        id: 4,
        image : "https://cdni.autocarindia.com/Utils/ImageResizer.ashx?n=https://cdni.autocarindia.com/ExtraImages/20180912112134_Honda-Amaze-front-action.jpg&w=726&h=482&q=75&c=1",
        Cartitle: "AMAZE",
        Cardescription: "You can book car as per your choice."
    }, {
        id: 5,
        image : "https://cdni.autocarindia.com/Utils/ImageResizer.ashx?n=https://cms.haymarketindia.net/model/uploads/modelimages/Tata-Punch-260820211926.jpg&w=730&h=484&q=75&c=1",
        Cartitle: "TATA",
        Cardescription: "You can book car as per your choice."
    }, {
        id: 6,
        image : "https://media.zigcdn.com/media/model/2021/Feb/tata-nexon-4_360x240.jpg",
        Cartitle: "TATA",
        Cardescription: "You can book car as per your choice."
    }, {
        id: 7,
        image : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4cGmGmwkIimgDeHpwTgbNRhv0wJSJwtBSinhWHkoS&s",
        Cartitle: "SUZUKI",
        Cardescription: "You can book car as per your choice."
    },
    {
        id: 8,
        image : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkwp6Ecv308mMQ6oTMCHmM-8Eo9ejXBxlaZw&usqp=CAU",
        Cartitle: "TATA SAFARI",
        Cardescription: "You can book car as per your choice."
    },
    {
        id: 9,
        image : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNXegc5ENBjSGNQFu03FWHxmHhVDjPD27Gxw&usqp=CAU",
        Cartitle: "RENAULT",
        Cardescription: "You can book car as per your choice."
    },
    {
        id: 10,
        image : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1S-KiBHZbQDegLNp9tLw6hx2wjMIt0OGQ6g&usqp=CAU",
        Cartitle: "KIA",
        Cardescription: "You can book car as per your choice."
    }
];

export default mockCar;