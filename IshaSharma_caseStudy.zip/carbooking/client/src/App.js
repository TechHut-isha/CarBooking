import React from 'react'
import Navbar from './components/Navbar'
import MainPage from './components/MainPage'
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import BookingPage from './components/BookingPage';
import ViewPage from './components/ViewPage';
import ThanksPage from './components/ThanksPage';

const App = () => {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
          <Route path="/" element={<MainPage />} />
          <Route path="/BookingPage" element={<BookingPage />} />
          <Route path="/ViewPage" element={<ViewPage />} />
          <Route path="/ThanksPage" element={<ThanksPage />} />
       </Routes>   
    </BrowserRouter>
  )
}

export default App