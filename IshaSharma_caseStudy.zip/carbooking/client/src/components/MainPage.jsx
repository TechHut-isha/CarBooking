import React from 'react'
import BookingPopup from './BookingPopup';

const MainPage = () => {
    return (

        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="bd-placeholder-img" style={{ objectFit: "cover" }} width="100%" height="100%" src='https://www.bmw.com.mo/content/dam/bmw/marketHK/bmw_com_mo/images/MicrosoftTeams-image.png.asset.1626772378644.png' />
                <div class="container">
                    <div class="carousel-caption text-start">
                        <h1 style={{ fontSize: '5rem', fontStyle: 'italic', marginBottom: '5%' }}>Live the Life.</h1>
                        <p style={{ fontSize: '2rem', marginBottom: '15%' }} >Book a car here as per you choice!</p>
                        <BookingPopup />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default MainPage