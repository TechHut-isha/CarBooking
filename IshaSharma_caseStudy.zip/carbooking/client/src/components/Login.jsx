import { useEffect } from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import axios from 'axios';
import App from '../App';

function Login() {
    const { loginWithPopup, user, isAuthenticated, getAccessTokenSilently } = useAuth0();

    useEffect(() => {
        CallProtectedApi();
    }, [isAuthenticated])

    async function CallProtectedApi() {
        try {
            const token = await getAccessTokenSilently();
            console.log(token);

            const response = await axios.post("http://localhost:3001/login", {
                headers: {
                    authorization: `Bearer ${token}`,
                },
            });
            console.log(response.data.dataCollection);
        } catch (error) {
            console.log(error.message);
        }
    }
    return (
        <div>
            {isAuthenticated ? <App /> : 
            <div className='login'>
            <h1>For SignIn & SignUp Click On button</h1>
                <button class="btn btn-warning" onClick={loginWithPopup}>SignIn || SignUp</button>
            </div>}
        </div>
    );
}

export default Login;

