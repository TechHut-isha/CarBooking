import React from 'react'
import mockCar from '../mockCar';
import CarCard from './CarCard';


const BookingPage = () => {

    return (
        <div style={{backgroundColor: 'whitesmoke'}}>
        <h1 style={{fontStyle:'italic' ,display: 'flex', padding: '20px' ,justifyContent: 'center'}}>Choose Your Sedan</h1>
        <div class="row row-cols-1 row-cols-md-2  row-cols-lg-1">
        <div class='row'>
            {mockCar.map((car) => {
                return (
                    <CarCard
                        key= {car.id}
                        Cartitle={car.Cartitle}
                        image={car.image}
                        Cardescription={car.Cardescription}
                    />
                  
                );
            })}
            
        </div>
        </div>
        </div>
    )
}

export default BookingPage