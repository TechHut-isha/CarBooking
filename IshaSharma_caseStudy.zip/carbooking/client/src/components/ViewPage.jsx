// import React from 'react'
// import { useLocation } from 'react-router-dom'

// const ViewPage = () => {
//     const a = useLocation();
//     console.log(a);
//   return (
//     <div>ViewPage</div>
//   )
// }

// export default ViewPage

import { useState } from "react";
import { useLocation } from "react-router-dom";
import Navbar from "./Navbar";
import ConfirmationPopup from './ConfirmationPopup'
export default function ViewPage(props)
{
    let location=useLocation();
    console.log(location.state);
    const right={
        width:"300px",
        height:"300px",
        boxShadow:"10px 10px 10px 10px lightblue",
        justify:"center",
        margin:"auto",
        marginTop:"50px",
        width: "16rem",
      
       
    }
    let BookCard={
        width:"500px",
        height:"300px",
        justify:"center",
        margin:"auto",
        alignItems:"center",
        textAlign:"center"
    }
    let [totalPrice,setTotalPrice]=useState(location.state.price);
    function Driver(e)
    {
        if(e.target.checked)
        {
            setTotalPrice(100+parseInt(location.state.price))
        }
        else{
            setTotalPrice(location.state.price)
        }
    }
    function Booked()
    {
        <ConfirmationPopup />
    }
    return(
        <>
        <Navbar/>
       
        <div className="card" style={right }>
        <img className="card-img-top" src={location.state.image}  alt="Card image cap"/>
            <div className="card-body">
                <h5 className="card-title">{location.state.title}</h5>
                <p className="card-text">{location.state.desc}</p>
        </div>
        </div>
        <br></br>
        <div style={BookCard}>
           From: <input type="date"/>
           To: <input type="date"/>
           <br></br><br></br>
           <h3>Need Driver :<input type="checkBox" onChange={(e)=>Driver(e)}/></h3>
           <br></br>
           <h4>Total Price : ${totalPrice}</h4><br></br>
          <ConfirmationPopup />
        </div>
       
        </>
    )
}