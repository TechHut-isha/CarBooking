import { Card } from 'antd';
import React from 'react';
import {Link, Navigate} from 'react-router-dom';
const { Meta } = Card;

const CarCard = (props) => {
// function gothere(){
//   <Navigate to='/' />
// }
return(
  <Link to='/ViewPage' state={{image: props.image, title: props.Cartitle, desc: props.Cardescription}}>
  <Card
    hoverable
    // onClick={gothere}
    style={{
      width: 240,
      margin: 35,
      height: 260,
    }}
    cover={<img alt="cars" src={props.image} />}
  >
    <Meta title={props.Cartitle} description={props.Cardescription} />
  </Card>
  </Link>
);
}
export default CarCard;