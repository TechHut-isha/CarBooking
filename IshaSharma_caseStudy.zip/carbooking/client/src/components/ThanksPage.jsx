import React from 'react'

const ThanksPage = () => {
  return (
    <div className='login'>
        <h1>Thank You for choosing ur service!!!!!!</h1>
    </div>
  )
}

export default ThanksPage