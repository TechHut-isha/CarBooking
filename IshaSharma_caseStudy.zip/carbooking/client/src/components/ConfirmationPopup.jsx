import { Button, Modal } from 'antd';
import React, { useState } from 'react';
import 'antd/dist/antd.css';
import { useNavigate } from 'react-router-dom';
const BookingPopup = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const navigate = useNavigate();
 
  const showModal = () => {
    setIsModalOpen(true);
  };
  const navigateThanks = () => {
    navigate('/ThanksPage');
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  
  return (
    <>
      <Button style={{marginBottom: "10%"}} type="primary" onClick={showModal}>
     Book Now
      </Button>
      <Modal title="Are you sure?" open={isModalOpen} onOk={navigateThanks} onCancel={handleCancel}>
      </Modal>
    </>
  );
};
export default BookingPopup;