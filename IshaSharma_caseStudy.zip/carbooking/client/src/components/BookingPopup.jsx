import { Button, Modal } from 'antd';
import React, { useState } from 'react';
import 'antd/dist/antd.css';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
const BookingPopup = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [state, setState] = useState("");
  const [district, setDistrict] = useState("");
  const navigate = useNavigate();
 
  const showModal = () => {
    setIsModalOpen(true);
  };
  const navigateBooking = () => {
    navigate('/BookingPage');
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const handleStateChange = (e) => {
    setState(e.target.value);
  };
  const handleDistrictChange = (e) => {
    setDistrict(e.target.value);
};
  
  return (
    <>
      <Button style={{marginBottom: "10%"}} type="primary" onClick={showModal}>
     Book Now
      </Button>
      <Modal title="Select State and District" open={isModalOpen} onOk={navigateBooking} onCancel={handleCancel}>
        <form>
            <input type="text" placeholder="State" onChange={handleStateChange} />
            <input type="text" placeholder="District" onChange={handleDistrictChange} />
        </form>
      </Modal>
    </>
  );
};
export default BookingPopup;