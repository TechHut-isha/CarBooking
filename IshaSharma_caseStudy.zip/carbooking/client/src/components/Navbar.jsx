import React from 'react'
import { NavLink } from 'react-router-dom';
import Logout from './Logout';

const Navbar = () => {
    return (
        // <div>
        //     <nav class="navbar navbar-expand-lg bg-dark fixed-top">
        //         <div class="container-fluid">
        //             <a class="navbar-brand" href="#" style={{ color: "#fff" }}>CARS</a>
        //             <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-target="#navbarSupportedContent" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        //                 <span class="navbar-toggler-icon"></span>
        //             </button>
        //             <div class="collapse navbar-collapse" id="navbarSupportedContent">
        //                 <ul class="navbar-nav mr-auto">
        //                     <li className="nav-item">
        //                         <NavLink to="/">
        //                             <button>Home</button>
        //                         </NavLink>
        //                     </li>
        //                     <li className="nav-item">
        //                         <Logout />
        //                     </li>
        //                 </ul>    
        //             </div>
        //         </div>    
        //     </nav>
        // </div>
        <header>
            <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand">CarBooker</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <ul class="navbar-nav me-auto mb-2 mb-md-0">
                            <li className="nav-item">
                                <NavLink class="nav-link" to="/">
                                    <button>Home</button>
                                </NavLink>
                            </li>
                        </ul>
                        <Logout />
                    </div>
                </div>
            </nav>
        </header>
    )
}

export default Navbar