import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import Login from './components/Login';
import { Auth0Provider } from '@auth0/auth0-react';
import './styles.css'
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Auth0Provider
  domain="dev-pvbux0ud.us.auth0.com"
  clientId='EqooIkWxth4bIJbql5xTiy31hNQrQVys'
  redirectUri={window.location.origin}
  audience='this is a unique identifier'
  scope='openid profile email'
  >
  <Login />
  </Auth0Provider>

);