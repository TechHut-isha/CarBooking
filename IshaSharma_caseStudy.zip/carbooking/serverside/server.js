const dotenv = require('dotenv');
const express = require('express');
const app = express();
const cors = require('cors');
require('./database/dbconnection');
const Authentication = require('./Middlwares/Authentication');
// const bcryptjs = require('bcryptjs');
const User = require('./Model/userSchema');

dotenv.config({path: './config.env'})
const PORT  = process.env.PORT;
app.use(express.json());
app.use(cors);
app.post('/Register',async (req, res)=>{
        // Get body or Data
        console.log(req.body.username);
        const username = req.body.username;
        const email = req.body.email;
        const password = req.body.password;

        if(!username || !email || !password){
            return res.status(422).send("Please fill correct details");
        }

        User.findOne({email: email}).then((userExist)=>{
            if(userExist){
                return res.status(422).send("User already exists");   
            }
        })

        const createUser = new User({
            username : username,
            email : email,
            password : password
        });

        // Save Method is Used to Create User or Insert User
        // But Before Saving or Inserting, Password will Hash 
        // Because of Hashing. After Hash, It will save to DB
        const created = await createUser.save();
        console.log(created);
        res.status(200).send("Registered");
});

app.post('/login', Authentication.authenticate, async (req,res)=>{
   try{
    const {email, password} = req.body;
    if(!email|| !password){
        return res.status(422).send("Please fill the data");   
    }
    const userLogin = await User.findOne({email : email});
    console.log(userLogin);
    if(!userLogin)
        res.status(400).send("User Not Logged in");
    else{
        res.send("User login successfully");
    }    
   } catch(err){
    console.log(err);
   }
});

app.post('/email',(req,res)=>{
    res.send("email");
});

app.get('/state',(req,res)=>{
    res.send("state");
});

app.get('/distict',(req,res)=>{
    res.send("distict");
});

app.get('/', (req,res)=>{
    res.send('Homepage')
})

app.listen(PORT, ()=>{
    console.log("server running", PORT);
})